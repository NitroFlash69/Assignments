var expess= require("express");
//const res = require("express/lib/response");
var app = expess();
app.set("view engine",'ejs')
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.get('/', (req, res) => {
    res.render('rec');

  });
  app.get('/misal', (req, res) => {
    res.render('mi');

  });
  app.get('/pav', (req, res) => {
    res.render('pv');

  });
  app.get('/Bir', (req, res) => {
    res.render('by');

  });
  app.get('/puran', (req, res) => {
    res.render('pu');

  });


  app.listen(8080);

