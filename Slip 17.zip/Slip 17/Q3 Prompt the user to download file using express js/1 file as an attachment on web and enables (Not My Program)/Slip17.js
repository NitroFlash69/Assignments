var express = require('express');
var fs=require('fs');
var app = express();
var PORT = 3000;

var bodyparser=require("body-parser");
app.use(bodyparser.urlencoded({extended:false}));
app.get('/',function(req,res){
    const files=fs.createReadStream('Slip17.html');
    res.writeHead(200,{'content-Type':'text/html'});
    files.pipe(res);
});

app.post('/file-data',function(req,res){
    var name=req.body.id;
    res.download(name);
});

app.listen(PORT, function(err){
    if (err) console.log(err);
    console.log("Server listening on PORT", PORT);
});