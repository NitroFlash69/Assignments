const express = require('express')
const app = express()
var bodyParser = require('body-parser')


const port = 3000


app.use(bodyParser.urlencoded({ extended: false }))


app.get('/', (req, res) => {
    
    res.sendFile(__dirname + '/download.html')
  })

const multer  = require('multer')

const upload = multer({ dest: 'download/' })
app.post('/upload', upload.single('image'), (req, res) => {
    console.log(req.file)
    res.download("./uploads/test.txt");
    res.send("File downloaded")
  })
app.listen(8080);
