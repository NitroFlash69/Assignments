public class Green implements Color 
{
	public void fillColor() 
	{
		System.out.println("Fill Green Color.");
	}
}