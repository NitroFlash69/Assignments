public class Square implements Shape 
{
	public void drawShape()
	{
		System.out.println("Shape Square.");
	}
}