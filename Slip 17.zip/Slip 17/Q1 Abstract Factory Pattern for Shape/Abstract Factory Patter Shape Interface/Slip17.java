public class Slip17
{
	public static void main(String args[])
	{

	      AbstractFactory shapeFactory = FactoryGenerator.getFactory("Shape");


	      Shape shape1 = shapeFactory.getShape("Circle");
	      shape1.drawShape();


	      Shape shape2 = shapeFactory.getShape("Rectangle");
	      shape2.drawShape();


	      Shape shape3 = shapeFactory.getShape("Square");
          shape3.drawShape();


	      AbstractFactory colorFactory = FactoryGenerator.getFactory("Color");


	      Color color1 = colorFactory.getColor("Red");
	      color1.fillColor();


	      Color color2 = colorFactory.getColor("Green");
	      color2.fillColor();


	      Color color3 = colorFactory.getColor("Blue");
	      color3.fillColor();
	}
}