public class Red implements Color 
{
	public void fillColor() 
	{
		System.out.println("Fill Red Color.");
	}
}