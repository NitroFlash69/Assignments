/**
 * NyStyleCheesePizza
 */
public class NYStyleCheesePizza extends Pizza {
    public NYStyleCheesePizza() {
        name = "NY Style Sauce and Cheese Pizza";
        dough = "Thin Crust Dough"; // 薄饼
        sauce = "Marinara sauce"; // 大蒜和番茄酱

        toppings.add("Grated Reggino Cheese"); /// 意大利 reggino 高级干酪
    }
}