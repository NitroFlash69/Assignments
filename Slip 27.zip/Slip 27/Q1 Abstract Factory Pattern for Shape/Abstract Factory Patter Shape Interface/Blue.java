public class Blue implements Color 
{
	public void fillColor() 
	{
		System.out.println("Fill Blue Color.");
	}
}