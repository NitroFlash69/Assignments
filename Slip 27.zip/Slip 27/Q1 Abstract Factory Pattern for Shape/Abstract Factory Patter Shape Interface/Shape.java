public interface Shape
{
	void drawShape();
}