class SingleTonPattern
{
  private static SingleTonPattern instance;
 
  private SingleTonPattern()
  {
    
  }
 
  synchronized public static SingleTonPattern getInstance()
  {
    if (instance == null)
    {
      instance = new SingleTonPattern();
    }
    return instance;
  }
}

class Ass1Q2
{
	public static void main(String[] str)
	{
		SingleTonPattern retinstance1 = SingleTonPattern.getInstance();
		SingleTonPattern retinstance2 = SingleTonPattern.getInstance();
                SingleTonPattern retinstance3 = SingleTonPattern.getInstance();
                System.out.println("Instance 1 :  "+ retinstance1);
		System.out.println("Instance 2 :  "+ retinstance2);
                System.out.println("Instance 3 :  "+ retinstance3);
		System.out.println("Successfully got one instance ");

		try{
			//SingleTonPattern instance = new SingleTonPattern();
		    }
               catch(Exception obj)
		{
			System.out.println("Exception :  "+ obj);
		}
	}
}

