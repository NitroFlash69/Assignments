

public class MuteQuack implements QuackBehavior{


	public void quack() {
System.err.println("Can't Quack");
	}


}
