

public class RubberDuck  extends Duck{


	public RubberDuck() {
		flyBehavior=new FlyNoWay();
		quackbehavior=new Quack();
	}

	public void display() {
		System.out.println("Looks like a Rubber Duck");
			}

}
