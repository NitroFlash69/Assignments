var mysql = require('mysql');
  
var con = mysql.createConnection({  
host: "localhost",  
user: "root",  
password: "",  
database: "Work1"  
});  

con.connect(function(err) {  
if (err) throw err;  
console.log("Connected!");  
var sql = "CREATE TABLE customers1 (id INT PRIMARY KEY, name VARCHAR(255), age INT(3), city VARCHAR(255))";  
con.query(sql, function (err, result) {  
if (err) throw err;  
console.log("Table created");  
});  
});  