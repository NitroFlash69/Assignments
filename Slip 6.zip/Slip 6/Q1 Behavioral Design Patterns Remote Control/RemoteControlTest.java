// A simple Java program to demonstrate
// implementation of Command Pattern using
// a remote control example.

// An interface for command
interface Command
{
	public void execute();
}

// Light class and its corresponding command
// classes
class Light
{
	public void on()
	{
		System.out.println("Light is on");
	}
	public void off()
	{
		System.out.println("Light is off");
	}
}
class LightOnCommand implements Command
{
	Light light;

	// The constructor is passed the light it
	// is going to control.
	public LightOnCommand(Light light)
	{
	this.light = light;
	}
	public void execute()
	{
	light.on();
	}
}
class LightOffCommand implements Command
{
	Light light;
	public LightOffCommand(Light light)
	{
		this.light = light;
	}
	public void execute()
	{
		light.off();
	}
}

// Stereo and its command classes
class Stereo
{
	public void on()
	{
		System.out.println("Stereo is on");
	}
	public void off()
	{
		System.out.println("Stereo is off");
	}
	public void setCD()
	{
		System.out.println("Stereo is set " +
						"for CD input");
	}
	public void setDVD()
	{
		System.out.println("Stereo is set"+
						" for DVD input");
	}
	public void setRadio()
	{
		System.out.println("Stereo is set" +
						" for Radio");
	}
	public void setVolume(int volume)
	{
	// code to set the volume
	System.out.println("Stereo volume set"
						+ " to " + volume);
	}
}

class StereoOffCommand implements Command
{
	Stereo stereo;
	public StereoOffCommand(Stereo stereo)
	{
		this.stereo = stereo;
	}
	public void execute()
	{
	stereo.off();
	}
}
class StereoOnWithCDCommand implements Command
{
	Stereo stereo;
	public StereoOnWithCDCommand(Stereo stereo)
	{
		this.stereo = stereo;
	}
	public void execute()
	{
		stereo.on();
		stereo.setCD();
		stereo.setVolume(11);
	}
}

class GarageDoor
{
	public void up()
	{
		System.out.println("GarageDoorOpen");
	}
        public void down()
	{
		System.out.println("GarageDoorClose");
	}
}


class GarageDoorOpenCommand implements Command {
    
       GarageDoor garegeDoor;
       
       public GarageDoorOpenCommand(GarageDoor garegeDoor)
        {
            this.garegeDoor = garegeDoor;
           
       }
       
       public void execute()
{
       
            garegeDoor.up();
       }
 }

class GarageDoorCloseCommand implements Command {
    
       GarageDoor garegeDoor;
       
       public GarageDoorCloseCommand(GarageDoor garegeDoor){
            this.garegeDoor = garegeDoor;
           
       }
       
       public void execute()
          {
       
            garegeDoor.down();
       }
 }

class LivingRoom
{
	public void on()
	{
		System.out.println("CeilingFan is on");
	}
	public void off()
	{
		System.out.println("CeilingFan is off");
	}
}
class CeilingFanOnCommand implements Command
{
	LivingRoom livingRoom;

	
	public CeilingFanOnCommand(LivingRoom livingRoom)
	{
	this.livingRoom = livingRoom;
	}
	public void execute()
	{
	livingRoom.on();
	}
}
class CeilingFanOffCommand implements Command
{
	LivingRoom livingRoom;

	
	public CeilingFanOffCommand(LivingRoom livingRoom)
	{
	this.livingRoom = livingRoom;
	}
	public void execute()
	{
	livingRoom.off();
	}
}


// A Simple remote control with one button
class SimpleRemoteControl
{
	Command slot; // only one button

	public SimpleRemoteControl()
	{
	}

	public void setCommand(Command command)
	{
		// set the command the remote will
		// execute
		slot = command;
	}

	public void buttonWasPressed()
	{
		slot.execute();
	}
}

// Driver class
class RemoteControlTest
{
	public static void main(String[] args)
	{
		SimpleRemoteControl remote =
				new SimpleRemoteControl();
		Light light = new Light();
		Stereo stereo = new Stereo();
               GarageDoor garegeDoor = new GarageDoor();
               LivingRoom livingRoom = new LivingRoom();


		// we can change command dynamically
		remote.setCommand(new
					LightOnCommand(light));
		remote.buttonWasPressed();
		remote.setCommand(new
				StereoOnWithCDCommand(stereo));
		remote.buttonWasPressed();
		remote.setCommand(new
				StereoOffCommand(stereo));
		remote.buttonWasPressed();
               
                      remote.setCommand(new
					CeilingFanOnCommand(livingRoom));
                  remote.buttonWasPressed();

                remote.setCommand(new
				GarageDoorCloseCommand(garegeDoor));
		remote.buttonWasPressed();

	}
}

