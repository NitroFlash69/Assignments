var http = require('http');
var fs = require('fs');

var server=http.createServer(function(req, res){
    fs.open('file1.txt','r+',function(err,fd){
        if(err){
            console.error(err);
            return res.end("404 File not found");
        }
        else{
            console.log("File Opended successfully");
            fs.readFile('file1.txt',function(err,data){
                if(!err){
                console.log('success');
                res.end(data);
                fs.close(fd);
            }
            });
        }
    });
}).listen(7000);