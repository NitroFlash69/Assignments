
public class Light
{
    String light;

	public Light(String light)
	{
		this.light=light;
	}

    public void on()
    {
	   System.out.println("Light is on");
    }

    public void off()
    {
	   System.out.println("Light is off");
    }
}
