
public class Stereo
{
    String stereo;

	public Stereo(String stereo)
	{
		this.stereo=stereo;
	}

	public void on()
	{
		System.out.println("Stereo is opened");
	}

	public void off()
	{
		System.out.println("Stereo is closed");
	}

}
