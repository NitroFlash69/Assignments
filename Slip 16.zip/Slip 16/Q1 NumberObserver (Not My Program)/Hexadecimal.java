

public class Hexadecimal implements Observer {
	 private int number;
		public NumberData numberData;

		 public Hexadecimal( NumberData numberData ) {
			 this.numberData = numberData;
			 numberData.registerObserver(this);
		 }


		@Override
		public void update(Integer number) {
			// TODO Auto-generated method stub
			System.out.println("Hexadecimal no:	"+ Integer.toHexString(number));
		}
}
