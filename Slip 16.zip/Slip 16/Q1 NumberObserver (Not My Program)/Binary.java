

public class Binary implements Observer {

	 private int number;
	public NumberData numberData;

	 public Binary( NumberData numberData ) {
		 this.numberData = numberData;
		 numberData.registerObserver(this);
	 }


	@Override
	public void update(Integer number) {
		// TODO Auto-generated method stub
		System.out.println("Binary no:	"+ Integer.toBinaryString(number));
	}

}
