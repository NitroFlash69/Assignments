//import event module
var events=require('events');

//create an eventEmitter object
var eventEmitter=new events.EventEmitter();

//create an event handler
var connectHandler=function connected(s){
    console.log('Its',s);
}

//Bind the connection event with the handler
eventEmitter.on('data_received',function(name){
    console.log(name,"Understood Event-Driven");
});

eventEmitter.emit('data_received',"PETER");

eventEmitter.on('connection',connectHandler);
eventEmitter.emit('connection',"Simple Solution");

console.log("Program Ended");