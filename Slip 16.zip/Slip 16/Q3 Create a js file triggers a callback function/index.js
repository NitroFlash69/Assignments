const EventEmitter = require('events');
var eventEmitter = new EventEmitter();
const readline = require('readline');

eventEmitter.on('hello', () => console.log('Hello wadia college'));
eventEmitter.on('bye', () => console.log('See you tomorrow...'));

readline.emitKeypressEvents(process.stdin);
if (process.stdin.isTTY)
	process.stdin.setRawMode(true);
process.stdin.on('keypress', (chunk, key) => {
	if (key){
		if (key.name == 'h') eventEmitter.emit('hello');
		if (key.name == 'b') eventEmitter.emit('bye');
		if (key.name == 'q') process.exit();
	}
});
