public interface BeatObserver
{
	void updateBeat();
}
