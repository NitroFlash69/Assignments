
public class PizzaTestDrive {

	public static void main(String[] args) {
		PizzaStore nyStore = new NYPizzaStore();
		PizzaStore chicagoStore = new ChicagoPizzaStore();

		Pizza pizza = nyStore.orderPizza("veggie");//NYStyleCheesePizza
		System.out.println("First order was a " + pizza.getName() + "\n");
	//	System.out.println(" "+pizza+"\n");

		System.out.println("----------------------------------------");
		
		pizza = chicagoStore.orderPizza("cheese");
		System.out.println("Second order was a " + pizza.getName() + "\n");
		//System.out.println(" "+pizza+"\n");

	}
}
