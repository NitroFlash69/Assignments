const mongoose = require('mongoose');

const url = 'mongodb://192.168.100.203:27017/db';

mongoose.connect(url);
const studentData = mongoose.model('student',mongoose.Schema({rno:Number, name:String, div:String}));

const data = [
                {rno:1,name:'Krutika',div:'A'},
                {rno:11,name:'Pranav',div:'B'},
                {rno:22,name:'Prasad',div:'C'},
                {rno:2,name:'Teju',div:'B'}
           ];

studentData.insertMany(data).then(() => console.log('Data is inserted successfully')).catch((err) => console.log(err));
