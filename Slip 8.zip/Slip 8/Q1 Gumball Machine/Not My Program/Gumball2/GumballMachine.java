

public class GumballMachine
{
	public State state;


	GumballMachine(int count)
	{
		this.state=new GumballEmpty(count,null);

	}

	public void setState(State state)
	{
		this.state=state;
	}

	public void putCoin()
	{
		state.putCoin(this);
	}

	public void pressButton()
	{
		state.pressButton(this);
	}

	public void addGumballs()
	{
		state.addGumballs(this);
	}
}
