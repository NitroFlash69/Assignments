public class BasicCar implements Car
{
    public void assemble()
    {
        System.out.println("Basic Car.");
    }
}