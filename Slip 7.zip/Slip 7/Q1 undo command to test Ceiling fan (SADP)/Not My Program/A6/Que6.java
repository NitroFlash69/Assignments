interface Command
{
	public void execute();
}

class Fan
{
  public static final int HIGH = 3,MEDIUM = 2,LOW = 1, OFF = 0;
  int speed=2;

  public void undo()
  {
    if (speed == 3)
    System.out.println( "Currently ceiling fan is on High State");
    else if (speed == 2)
    System.out.println( "Currently ceiling fan is on medium State");
    else if (speed == 1)
    System.out.println( "Currently ceiling fan is on low state");

    System.out.println("Undo performed");

	if (speed == HIGH)
    {
		speed--;
		System.out.println( "Now ceiling fan is on medium");
    }
	else if (speed == MEDIUM)
    {
		speed--;
		System.out.println( "Now ceiling fan is on low");
    }
	else if (speed == LOW)
	{
		speed--;
		System.out.println( "Now ceiling fan is on off");
    }
}
	public void on()
	{
		System.out.println("Fan is on");
	}
	public void off()
	{
		System.out.println("Fan is off");
	}

}
class FanOnCommand implements Command
{
	Fan Fan;
    // The constructor is passed the Fan it is going to control.
	public FanOnCommand(Fan Fan)
	{
	  this.Fan = Fan;
	}

	public void execute()
	{
	  Fan.on();
	}
}

class FanOffCommand implements Command
{
	Fan Fan;

	public FanOffCommand(Fan Fan)
	{
		this.Fan = Fan;
	}
	public void execute()
	{
		Fan.off();
	}
}

class Undo implements Command
{
    Fan Fan;

	public Undo(Fan Fan)
	{
		this.Fan = Fan;
	}
	public void execute()
	{
		Fan.undo();
	}

}

// A Simple remote control with one button
class SimpleRemoteControl
{
	Command slot; // only one button

	public SimpleRemoteControl()  { }
	public void setCommand(Command command)
	{                 // set the command the remote will execute
		slot = command;
	}

    public void buttonWasPressed()
	{
		slot.execute();
	}
}

class Que6
{
	public static void main(String args[])
	{
		SimpleRemoteControl remote =new SimpleRemoteControl();
		Fan Fan = new Fan();

		remote.setCommand(new FanOnCommand(Fan));
		remote.buttonWasPressed();

		remote.setCommand(new Undo(Fan));
		remote.buttonWasPressed();

		remote.setCommand(new FanOffCommand(Fan));
		remote.buttonWasPressed();
	}
}
