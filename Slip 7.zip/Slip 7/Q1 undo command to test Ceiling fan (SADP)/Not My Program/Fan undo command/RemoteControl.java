
public class RemoteControl
{
     Command onCommand;
	 Command offCommand;
	 Command undocommand;

	public void setCommand(int slot, Command onCommand, Command offCommand)
	{
		 this.onCommand = onCommand;
		 this.offCommand= offCommand;
	}

	public void onButtonWasPushed(int slot)
	{
		 onCommand.execute();
		 undocommand = onCommand;
	}

	public void offButtonWasPushed(int slot)
	{
		 offCommand.execute();
		 undocommand = offCommand;
	}

	 public void undoButtonWasPushed()
	 {
		 undocommand.undo();
	 }
y}


