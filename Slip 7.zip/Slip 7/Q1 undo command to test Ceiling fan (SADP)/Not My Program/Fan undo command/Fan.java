
public class Fan
{
    String Fan;

	public Fan(String Fan)
	{
		this.Fan=Fan;
	}

	public void on()
	{
		System.out.println("Fan on");

	}

	public void off()
	{
		System.out.println("Fan off");

	}
}
