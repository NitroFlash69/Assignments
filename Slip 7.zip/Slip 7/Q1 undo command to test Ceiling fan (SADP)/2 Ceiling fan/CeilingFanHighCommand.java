public class CeilingFanHighCommand implements Command 
{
	CeilingFan ceilingFan;
	int prevSpeed;                          //local state to track prev speed of fan

	public CeilingFanHighCommand(CeilingFan ceilingFan) 
	{
		this.ceilingFan = ceilingFan;
	}

	public void execute() 
	{
		prevSpeed = ceilingFan.getSpeed();  //before speed change,it records the prev state just incase to perform undo actions
		ceilingFan.high();
		
	}

	public void undo() 
	{
		if (prevSpeed == CeilingFan.HIGH) 
		{
			ceilingFan.high();
		} 
		else if (prevSpeed == CeilingFan.MEDIUM) 
		{
			ceilingFan.medium();                               //to undo, set speed of fan back to its prev speed
		} 
		else if (prevSpeed == CeilingFan.LOW) 
		{
			ceilingFan.low();
		} 
		else if (prevSpeed == CeilingFan.OFF) 
		{
			ceilingFan.off();
		}
	}
}
