import java.util.*;
import java.util.Vector;
import java.util.Enumeration;

public class ass2a2{

	public static void main(String args[])
	{
		Enumeration nums;
		Vector<String> subject = new Vector<>();

		subject.add("Statistics");
		subject.add("English");
		subject.add("Computer Science");
                subject.add("Science");
		nums = subject.elements();
		EnumerationIterator ei = new EnumerationIterator(nums);
		while(ei.hasNext())
		{
			System.out.println(ei.next());
		}
	}
}

class EnumerationIterator implements Iterator
{
	Enumeration et;
	public EnumerationIterator(Enumeration et) 
	{
		this.et = et;
	}
	public boolean hasNext() 
	{
		return et.hasMoreElements();
	}
	public Object next() 
	{
		return et.nextElement();
	}
	public void remove() 
	{
		throw new UnsupportedOperationException();
	}
}
