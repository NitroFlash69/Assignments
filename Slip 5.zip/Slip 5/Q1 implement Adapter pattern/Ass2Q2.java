import java.util.Enumeration;
import java.util.Iterator;
import java.util.ArrayList;

class MyEnumeratorAdapter<Object> implements Enumeration<Object> {

    private Iterator<Object> adaptee;

    public MyEnumeratorAdapter(Iterator<Object> it) {
        this.adaptee = it;
    }

    public boolean hasMoreElements() {
        return adaptee.hasNext();
    }

    public Object nextElement() {
        return adaptee.next();
    }

   public Object remove() {
        throw new UnsupportedOperationException();
    }
}

class MyArrayList<T> extends ArrayList<T> {

    public Enumeration<T> enumerator() {
        return new MyEnumeratorAdapter(this.iterator());
    }
}


class Ass2Q2{

public static void main(String[] args) {
        MyArrayList<String> names = new MyArrayList<String>();
        names.add("Prashant");
        names.add("Sujit");
        names.add("Aavni");

        for (Enumeration<String> iterator = names.enumerator(); iterator
                .hasMoreElements();) {
            String name = (String) iterator.nextElement();
            System.out.println(name);
        }

    }
}
