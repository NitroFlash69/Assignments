import java.util.Arrays;
import java.util.Enumeration;
import java.util.Vector;

public class Que7
{
	public static void main(String args[])
	{
		Vector<String> v = new Vector<>(Arrays.asList("C", "Java", "C++", "Python"));
		Enumeration<String> e = v.elements();

		Iterator<String> it = new EnumerationIterator<String>(e);

		while (it.hasNext())
		{
			System.out.println(it.next());
		}
	}
}
