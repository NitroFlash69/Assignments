
import java.util.Enumeration;

public class EnumerationIterator<T> implements Iterator<T> {
	Enumeration<T> e;
	
	public EnumerationIterator(Enumeration<T> e) {
		this.e = e;
	}
	
	@Override
	public boolean hasNext() {
		return e.hasMoreElements();
	}

	@Override
	public T next() {
		return e.nextElement();
	}

	@Override
	public void remove() {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException();

	}
	
		
	
}

