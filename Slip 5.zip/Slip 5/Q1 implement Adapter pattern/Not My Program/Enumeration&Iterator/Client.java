
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Vector;

public class Client {
	public static void main(String[] args) {
		
		
		Vector<Integer> vector = new Vector(Arrays.asList(1,2,3,4,5,6,7,8,9));
		Enumeration<Integer> enumeration = vector.elements();
		
		
		Iterator<Integer> iterator = new EnumerationIterator<Integer>(enumeration);
		
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		//iterator.remove();
	}
}