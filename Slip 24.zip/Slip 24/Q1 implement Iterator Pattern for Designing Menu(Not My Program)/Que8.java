import java.util.Iterator;
import java.util.*;
import java.lang.*;

interface Menu
{
  public Iterator createIterator();
  String name="SP";
  abstract String getName();
}

class MenuItem
{
  String name;
  String desc;

  public MenuItem(String name, String desc)
  {
    this.name = name;
    this.desc = desc;
  }

  public String getName()
  {
	 return name;
  }

  public String getdesc()
  {
	 return desc;
  }
 }

class BMenu implements Menu
{
	ArrayList<MenuItem> menuItems;
 	String name;

  @Override
  public String getName()
  {
	return name;
  }

  public BMenu()
  {
		name = "*********BREAKFAST*********";

		menuItems = new ArrayList<MenuItem>();
        addItem("French Toast", "Toast with Pancakes");
        addItem("Hot Drinks", "Hot Tea with biscuits");
        addItem("Fruit Drinks", "All fruit Juices ");
        addItem("Blueberry Pancakes","Pancakes and blueberry syrup");
  }

  public void addItem(String name, String desc)
  {
		MenuItem menuItem = new MenuItem(name, desc);
		menuItems.add(menuItem);
  }

  public ArrayList<MenuItem> getMenuItems()
  {
		return menuItems;
  }

  public Iterator<MenuItem> createIterator()
  {
	  return menuItems.iterator();
  }
 }

class DinerMenu implements Menu
{
	static final int MAX_ITEMS = 5;
	int numberOfItems = 0;
	MenuItem[] menuItems;
  	String name;

  @Override
  public String getName()
  {
	 return name;
  }

  public DinerMenu()
  {
	  name = "******LUNCH*******";

	  menuItems = new MenuItem[MAX_ITEMS];
      addItem("Vada Pav"," Paneer Vada pav with french fries");
      addItem("Pav Baji"," Special pav baji with fried pav");
      addItem("Misal Pav"," Soup of the day, with a side of potato salad");
      addItem("Pizza"," Golden corn pizza");
      addItem("South Indian Thali"," Special veg south indian thali");
   }

  public void addItem(String name, String desc)
  {
     MenuItem menuItem = new MenuItem(name, desc);
     menuItems[numberOfItems] = menuItem;
     numberOfItems = numberOfItems + 1;
  }

  public MenuItem[] getMenuItems()
  {
	 return menuItems;
  }

  public Iterator<MenuItem> createIterator()
  {
	 return new DinerMenuIterator(menuItems);
  }

  class DinerMenuIterator implements Iterator<MenuItem>
  {
	MenuItem[] list;
	int position = 0;
 	String name;

	public DinerMenuIterator(MenuItem[] list)
	{
		this.list = list;
	}

    public MenuItem next()
    {
		MenuItem menuItem = list[position];
		position = position + 1;
		return menuItem;
	}

    public boolean hasNext()
    {
		if (position >= list.length || list[position] == null)
			return false;
		 else
			return true;
    }
   }
}

class Service
{
	ArrayList<Menu> menus;

     public Service(ArrayList<Menu> menus)
     {
		this.menus = menus;
     }

     public void printMenu()
     {
		Iterator menuIterator = menus.iterator();
		System.out.print("*****Welcome********\n----\n");

		while(menuIterator.hasNext())
		{
            System.out.println("MENU");
			Menu menu = (Menu)menuIterator.next();
			System.out.print("\n" + menu.getName() + "\n");
			printMenu(menu.createIterator());
		}
}

 void printMenu(Iterator iterator)
 {
		while (iterator.hasNext())
		{
			MenuItem menuItem = (MenuItem)iterator.next();
			System.out.print(menuItem.getName() + ", ");
			System.out.println(menuItem.getdesc());
		}
 }
}

class Que8
{
	public static void main(String args[])
    {
		BMenu BMenu = new BMenu();
		DinerMenu dinerMenu = new DinerMenu();

		ArrayList<Menu> menus = new ArrayList<Menu>();
		menus.add(BMenu);
		menus.add(dinerMenu);

		Service Service = new Service(menus);
		Service.printMenu();
    }
 }