
public class GarageDoorDownCommand implements Command
{
   Garage garage;

   GarageDoorDownCommand(Garage garage)
   {
		this.garage=garage;
   }

	public void execute()
	{
		garage.down();
	}
}
