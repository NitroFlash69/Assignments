
public class Garage
{
    String garage;

	public Garage(String garage)
	{
		this.garage=garage;
	}

	public void up()
	{
		System.out.println("Garage Door is opened");
	}

	public void down()
	{
		System.out.println("Garage Door is closed");
	}
}
