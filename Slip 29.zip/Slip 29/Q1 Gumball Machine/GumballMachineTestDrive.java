
public class GumballMachineTestDrive {

	public static void main(String[] args) {
		GumballMachine gumballMachine = new GumballMachine(2); //load it up with 2 gumball

		System.out.println(gumballMachine);   //print state

		gumballMachine.insertQuarter();      //throw quarter in
		gumballMachine.turnCrank();          //turn the crank get the gumball

		System.out.println(gumballMachine);  //print state

		gumballMachine.insertQuarter();      //throw quarter in 
		gumballMachine.turnCrank();          //turn crank get the gumball
		gumballMachine.insertQuarter();
		gumballMachine.turnCrank();
		
		gumballMachine.refill(5);
		gumballMachine.insertQuarter();
		gumballMachine.turnCrank();
     

		System.out.println(gumballMachine);
	}
}
