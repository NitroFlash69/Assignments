
public interface State
{
		void putCoin(GumballMachine context);
		void pressButton(GumballMachine context);
		void addGumballs(GumballMachine context);
}
