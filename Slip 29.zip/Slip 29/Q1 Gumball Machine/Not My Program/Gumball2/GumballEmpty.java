

public class GumballEmpty implements State
{

	public GumballMachine context;
    public int gumball_count;

	public GumballEmpty(int count,GumballMachine context)
	{
		this.context=context;
		this.gumball_count=count;
	}

	public void putCoin(GumballMachine context)
	{
		System.out.println("Gumball Machine is empty");
	}

	public void pressButton(GumballMachine context)
	{
		System.out.println("Gumball Machine is empty");
	}

	public void addGumballs(GumballMachine context)
	{
		System.out.println("Gumballs Added");
		context.setState(new GumballStart(gumball_count,context));
	}

}
