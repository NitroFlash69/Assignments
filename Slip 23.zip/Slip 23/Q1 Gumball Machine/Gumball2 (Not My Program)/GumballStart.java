

public class GumballStart implements State
{
	public  int gumball_count;
	public GumballMachine context;

	public GumballStart(int count,GumballMachine context)
	{
		this.gumball_count = count;
		this.context=context;
	}

	public void putCoin(GumballMachine context)
	{
		System.out.println("Coin received, please press button to get Gumballs");
		context.setState(new GumballDispenser(gumball_count,context));
	}

	public void pressButton(GumballMachine context)
	{
		System.out.println("Please insert coin before pressing Button");
	}

	public void addGumballs(GumballMachine context)
	{
		System.out.println("Gumballs Added");
		context.setState(new GumballStart(gumball_count,context));
	}
}
