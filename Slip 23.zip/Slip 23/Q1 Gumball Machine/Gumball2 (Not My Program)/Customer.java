
public class Customer
{

	public static void main(String args[])
	{


		GumballMachine gumball_machine = new GumballMachine(20);
		gumball_machine.addGumballs();

		gumball_machine.putCoin();
		gumball_machine.pressButton();
		System.out.println("-----------------------------");


		gumball_machine.putCoin();
		gumball_machine.pressButton();
		System.out.println("-----------------------------");


		gumball_machine.putCoin();
		gumball_machine.pressButton();
		System.out.println("-----------------------------");

		gumball_machine.putCoin();
		gumball_machine.pressButton();
		System.out.println("-----------------------------");
		gumball_machine.putCoin();
		gumball_machine.pressButton();
		System.out.println("-----------------------------");
		gumball_machine.putCoin();
		gumball_machine.pressButton();
		System.out.println("-----------------------------");

		gumball_machine.putCoin();
		gumball_machine.pressButton();
		System.out.println("-----------------------------");
		gumball_machine.putCoin();
		gumball_machine.pressButton();
		System.out.println("-----------------------------");
	}
}
