

public class GumballDispenser implements State
{

    public  int gumball_count;
    public GumballMachine context;

	public GumballDispenser(int count,GumballMachine context)
	{
		this.gumball_count = count;
		this.context=context;
	}

	public void putCoin(GumballMachine context)
	{
		System.out.println("Coin already inserted please press button to get Gumballs");
	}

	public void pressButton(GumballMachine context)
	{
		if (gumball_count - 3 <= 3)
			this.context.setState(new GumballEmpty(gumball_count,context));
		else
			context.setState(new GumballStart(gumball_count - 3,context));
	}

	public void addGumballs(GumballMachine context)
	{
		System.out.println("Gumballs Added");
		context.setState(new GumballDispenser(gumball_count,context));
	}
}
