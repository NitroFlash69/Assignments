const mongoose = require('mongoose');

const url = 'mongodb://192.168.100.203:27017/db';

mongoose.connect(url);

const myData = mongoose.model('customers',mongoose.Schema({name:String, id:Number, city:String}));

myData.deleteOne({name:'Rutuja'}).then(() => console.log('Data is removed successfully !!!')).catch((err) => console.log(err));


