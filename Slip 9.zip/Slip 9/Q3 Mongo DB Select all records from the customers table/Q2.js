const mongoose = require('mongoose');

const url = 'mongodb://192.168.100:203/mysql'

mongoose.connect(url);

const studentModel = mongoose.model('students', mongoose.Schema({
	rollno: Number,
	name: String,
	div: String
}));

const records = [
	{rollno: 32, name: 'student11', div:'A'},
	{rollno: 51, name: 'student22', div:'A'},
	{rollno: 34, name: 'student33', div:'B'}
];


studentModel.insertMany(records).then(() => console.log('Data inserted')).catch((err) => console.log(err));
