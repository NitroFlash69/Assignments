# Execution command:

```
./mvnw spring-boot:run
```

OR

```
./gradlew bootRun
```

Link: https://spring.io/guides/gs/handling-form-submission/
