var mysql = require('mysql');
  
var con = mysql.createConnection({  
host: "localhost",  
user: "root",  
password: "",  
database: "studentsdb"  
}); 

con.connect(function(err) {  
if (err) throw err;  
console.log("Connected!");  

var sql = "INSERT INTO login (uname,password) VALUES ?";  
var values = [  
['sans','sans'],  
['ghate','ghate']  
];  
  

con.query(sql, [values], function (err, result) {
if (err) throw err;
console.log("Number of records inserted: " + result.affectedRows);  
});

});