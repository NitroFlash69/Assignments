var mysql = require('mysql');
  
var con = mysql.createConnection({  
host: "localhost",  
user: "root",  
password: "",  
database: "studentsdb"  
});  

con.connect(function(err) {  
if (err) throw err;  
console.log("Connected!");  
var sql = "CREATE TABLE login (uname VARCHAR(25), password VARCHAR(25))";  
con.query(sql, function (err, result) {  
if (err) throw err;  
console.log("Table created");  
});  
});  