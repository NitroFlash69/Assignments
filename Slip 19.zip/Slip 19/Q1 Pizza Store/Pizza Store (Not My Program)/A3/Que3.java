import java.util.ArrayList;

abstract class pizzastore
{
	public pizza orderpizza(String type)
	{
		pizza pizza1;
		pizza1=createPizza(type);

		pizza1.prepare();
		pizza1.bake();
		pizza1.cut();
		pizza1.box();

		return pizza1;

	}
	protected abstract pizza createPizza(String type);
}

abstract class pizza
{
 String name;
 String dough;
 String sauce;
 ArrayList topping=new ArrayList();

 void prepare()
 {
	 System.out.println("Preparing "+name);
	 System.out.println("Tossing Dough");
	 System.out.println("Adding sauce");
	 System.out.println("Adding Toppings:");

	 for(int i=0;i<topping.size();i++)
	 {
		 System.out.println("  "+topping.get(i));
	 }
 }

 void bake()
 {
	 System.out.println("Bake for 25 minutes at 350");
 }

 void cut()
 {
	 System.out.println("Cutting the pizza into diagonal slice");
 }

 void box()
 {
	 System.out.println("Place pizza in official PizzaStore box");
 }

 public String getName()
 {
	 return name;
 }
}

class NYStyleCheesePizza extends pizza
{

	public NYStyleCheesePizza()
	{
		name="NYStyle sauce and cheese Pizza";
		topping.add("Grated reggiano Cheese");
	}
}


class ChicagoStyleCheesePizza extends pizza
{
	public ChicagoStyleCheesePizza()
	{
		name="ChicagoStyle sauce and cheese Pizza";
		topping.add("Shradded Mozzarella cheese");
	}

	void cut()
	{
		System.out.println("Cutting the pizza into sqare slice");
	}
}

class OrderPizza
{
	public pizza createPizza(String type)
	{
		pizza pizzsa1=null;
		if(type.equals("cheese"))
		{
			pizzsa1=new NYStyleCheesePizza();
		}else if(type.equals("cheese1"))
		{
			pizzsa1=new ChicagoStyleCheesePizza();

		}
		return pizzsa1;
	}
}

class SimplePizzaFactory
{
	OrderPizza nystore;

	public SimplePizzaFactory(OrderPizza nystore)
	{
		this.nystore=nystore;
	}

	public pizza orderpizza(String type)
	{
		pizza pizza1;
		pizza1=nystore.createPizza(type);

		pizza1.prepare();
		pizza1.bake();
		pizza1.cut();
		pizza1.box();

		return pizza1;
	}
}

public class Que3
{

	public static void main(String args[])
	{
		    OrderPizza nystore=new OrderPizza();

		    SimplePizzaFactory chicagostore=new SimplePizzaFactory(nystore);

            pizza pizza1=chicagostore.orderpizza("cheese");
	                System.out.println("Ethan ordered a"+pizza1.getName()+"\n");

	        pizza1=chicagostore.orderpizza("cheese1");
	                System.out.println("Joel ordered a"+pizza1.getName()+"\n");

	  }

 }

